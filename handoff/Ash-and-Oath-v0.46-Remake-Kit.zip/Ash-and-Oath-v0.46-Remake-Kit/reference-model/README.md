# Original gameplay model — optional reference

These are unchanged gameplay-domain scripts from source commit be9f5c2675a45d989976334c7f20c7e186d4a5ca. They provide exact validation, formulas, ordering and persistence logic. They are not a standalone runnable project, and your remake is not required to use Godot. Original res:// references are retained for source traceability. Presentation/HUD/art scripts and previous art-direction instructions are deliberately not part of this kit.

The exported rule data is generated from these definitions. Legacy compatibility branches/parameters in the code are not additional modern equipment layers. CORE_MECHANICS.md states the current authoritative four-slot system and optional-rule defaults.
