# Progression and encounter data

Exact recipes and source data are exported here; effect timing and restrictions remain in the full rules and model.

## Normal Essence types

### Bone Creature [bone_creature]

**condition**: regular

**faces**: [60, 61, 62]

**hp**: 3

**rank**: normal

### Bu’gh, the Iron Warden [bugh]

**condition**: regular

**faces**: []

**rank**: boss

### Veyl, the Brass Cantor [cantor]

**condition**: regular

**faces**: []

**rank**: boss

### Cinder Mite [cinder_mite]

**condition**: regular

**faces**: []

**rank**: normal

### Glasswing Moth [glasswing_moth]

**condition**: regular

**faces**: []

**hp**: 3

**rank**: normal

### The Hollow [hollow]

**condition**: regular

**faces**: []

**rank**: boss

### Iron Husk [iron_husk]

**condition**: regular

**faces**: []

**hp**: 5

**rank**: normal

### Mire Leech [mire_leech]

**condition**: regular

**faces**: []

**hp**: 4

**rank**: normal

### Movement Creature [movement_creature]

**condition**: regular

**faces**: [66, 67, 68]

**hp**: 3

**rank**: normal

### Nu’gh [nugh]

**condition**: regular

**faces**: []

**rank**: boss

### Screaming Worm [nugh_worm]

**condition**: regular

**faces**: []

**rank**: normal

### Ash Scavenger [scavenger]

**condition**: regular

**faces**: []

**rank**: normal

### Support Creature [support_creature]

**condition**: regular

**faces**: [63, 64, 65]

**hp**: 2

**rank**: normal

## Normal recipes

### bone_growth [bone_growth]

**category**: Skill Face · Bone

**cost**: 1

**enemy**: bone_creature

**face**: 60

### bone_guard [bone_guard]

**category**: Defense Face · Bone

**cost**: 3

**enemy**: bone_creature

**face**: 62

### bone_strike [bone_strike]

**category**: Attack Face · Bone

**cost**: 2

**enemy**: bone_creature

**face**: 61

### brood_needle [brood_needle]

**category**: Attack Face

**cost**: 2

**enemy**: nugh

**face**: 70

### ember_cut [ember_cut]

**category**: Attack Face

**cost**: 2

**enemy**: hollow

**face**: 69

### evasive [evasive]

**category**: Defense Face · Reaction

**cost**: 3

**enemy**: movement_creature

**face**: 68

### Glasswing Memory [glasswing_soul]

**category**: Memory

**cost**: 3

**effect**: Spend one rolled Blank to blink up to 2 orthogonal spaces, once per own turn. Landing must be empty; Rooted prevents this.

**enemy**: glasswing_moth

**memory**: glasswing

### iron_shelter [iron_shelter]

**category**: Defense Face

**cost**: 2

**enemy**: bugh

**face**: 72

### Ironbound Memory [iron_soul]

**category**: Memory

**cost**: 3

**effect**: Spend one rolled Blank to gain 2 Block, once per own turn.

**enemy**: iron_husk

**memory**: ironbound

### Memory of the Brood [memory_brood]

**category**: Memory

**cost**: 3

**effect**: Your first Poison application each own turn adds 1 extra Poison. Your friendly Nu’gh counts.

**enemy**: nugh

### Memory of Embers [memory_embers]

**category**: Memory

**cost**: 3

**effect**: Your first actual enemy HP damage each own turn grants 1 Block.

**enemy**: hollow

### Memory of the First Step [memory_first_step]

**category**: Memory

**cost**: 1

**effect**: Spend one rolled Blank as Move 1, once per own turn. The installed side remains Blank.

**enemy**: movement_creature

**memory**: first_step

### Memory of Iron [memory_iron]

**category**: Memory

**cost**: 3

**effect**: The first Defense you resolve each own turn grants 1 extra Block.

**enemy**: bugh

### Memory of Loss [memory_loss]

**category**: Memory

**cost**: 4

**effect**: Healing abilities gain +1 range except Self/Adjacent. The first actual self-heal each combat restores 1 extra HP.

**enemy**: support_creature

### Memory of Silence [memory_silence]

**category**: Memory

**cost**: 3

**effect**: The first Skill you resolve each own turn grants 1 Block.

**enemy**: cantor

### Memory of the Mire [mire_soul]

**category**: Memory

**cost**: 3

**effect**: Spend one rolled Blank to heal yourself 1 HP, once per own turn. Cannot revive yourself.

**enemy**: mire_leech

**memory**: mire

### momentum [momentum]

**category**: Attack Face

**cost**: 2

**enemy**: movement_creature

**face**: 67

### quiet_note [quiet_note]

**category**: Skill Face

**cost**: 2

**enemy**: cantor

**face**: 71

### retreat [retreat]

**category**: Movement Face

**cost**: 1

**enemy**: movement_creature

**face**: 66

### shared_burden [shared_burden]

**category**: Skill Face · Copy

**cost**: 3

**enemy**: support_creature

**face**: 65

### shared_remedy [shared_remedy]

**category**: Skill Face · Healing

**cost**: 1

**enemy**: support_creature

**face**: 63

### sorrow [sorrow]

**category**: Skill Face

**cost**: 2

**enemy**: support_creature

**face**: 64

### Oathblade [weapon_oathblade]

**category**: Weapon

**cost**: 4

**effect**: Attack faces: minimum 3 / maximum 6. Replace 3 basic Strikes → Oath Cut (1 adjacent damage each). Passive: ALL your Attack faces gain Pierce 1, including other equipped Attacks. Replacements spend rolled dice.

**enemy**: bugh

**weapon**: oathblade

## Trial Forge ingredients

### Cinder Essence [cinder]

**source**: The Long Charge; Break the Ritual

### Hollow Essence [hollow]

**source**: The Hollow, final Trial boss

### Shade Essence [shade]

**source**: Essence Thieves

### Ward Essence [ward]

**source**: Ward & Whisper; Protect the Spirit

## Trial Forge recipes

### Fleet Body [fleet]

**cost**: {"cinder": 3}

**item**: fleet

**slot**: body

### Memory of Hearth [hearth_soul]

**cost**: {"ward": 3}

**item**: hearth

**slot**: memory

### Heavy Dagger [heavy]

**cost**: {"cinder": 2, "hollow": 1}

**item**: heavy

**slot**: weapon

### Oathblade [oathblade]

**cost**: {"hollow": 2, "ward": 4}

**item**: oathblade

**slot**: weapon

### Memory of Shelter [shelter_memory]

**cost**: {"ward": 2}

**item**: shelter

**slot**: memory

### Stone Body [stone]

**cost**: {"ward": 3}

**item**: stone

**slot**: body

### Poison Dagger [venom]

**cost**: {"shade": 2}

**item**: venom

**slot**: weapon

### Memory of Wind [wind_soul]

**cost**: {"cinder": 3}

**item**: wind

**slot**: memory

## Trial objectives

### Break the Ritual [ritual]

**text**: Break all three violet ritual stones (2 HP each). Any Attack can damage them; they cannot move or receive Poison. Enemies retreat when all three break. Clearing only the creatures does not complete this objective. Victory: +3 Run Essence and 2 Cinder Essence.

### Protect the Spirit [spirit]

**text**: Keep the blue spirit (5 HP) alive through three enemy turns, or defeat all its attackers sooner. Enemies prefer the spirit when their ability can reach it; otherwise they target a hero. First Aid can heal it. Shield Wall and Taunt can protect it. Its death ends this Trial. Victory: +3 Run Essence and 2 Ward Essence.

## Trial enemy roles

### Glasswing Sentry [archer]

**dice**: [["Needle", "Scuttle", "Needle", "Guard", "Needle", "Scuttle"], ["Scuttle", "Needle", "Guard", "Needle", "Scuttle", "Needle"], ["Needle", "Guard", "Scuttle", "Needle", "Guard", "Scuttle"]]

**hp**: 2

**type**: glasswing_moth

### Whisper Mender [healer]

**dice**: [["Restitch", "Restitch", "Scuttle", "Guard", "Bite", "Restitch"], ["Restitch", "Guard", "Bite", "Scuttle", "Restitch", "Guard"], ["Bite", "Restitch", "Scuttle", "Guard", "Restitch", "Guard"]]

**hp**: 3

**type**: support_creature

### Cinder Ram [ram]

**dice**: [["Mark Charge", "Mark Charge", "Scuttle", "Bash", "Guard", "Mark Charge"], ["Scuttle", "Bash", "Guard", "Scuttle", "Bash", "Guard"], ["Bash", "Guard", "Scuttle", "Bash", "Guard", "Scuttle"]]

**hp**: 6

**type**: bone_creature

### Ash Shieldbearer [shield]

**dice**: [["Shield Line", "Scuttle", "Bash", "Shield Line", "Guard", "Bash"], ["Shield Line", "Bash", "Scuttle", "Guard", "Shield Line", "Bash"], ["Bash", "Guard", "Shield Line", "Scuttle", "Bash", "Guard"]]

**hp**: 4

**type**: iron_husk

### Essence Cutpurse [thief]

**dice**: [["Scuttle", "Pilfer", "Pilfer", "Bite", "Flee", "Scuttle"], ["Pilfer", "Pilfer", "Flee", "Bite", "Scuttle", "Pilfer"], ["Flee", "Bite", "Pilfer", "Flee", "Scuttle", "Flee"]]

**hp**: 4

**type**: movement_creature
