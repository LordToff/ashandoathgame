# Enemy families, boss dice and Trial role actions

The family registry includes harvesting records for summons/worms as well as selectable ordinary creatures. A family record is not a guarantee of a separate selectable encounter. Nu’gh worms/friendly summons use their specific summoner rules, not generic ordinary-creature dice.

## Bone Creature [bone_creature]

Scuttle 2 (Movement: 3), Bite 1, Guard 1. Support can Mend 1 within 2.

HP: 3

Ordinary-creature-profile dice: [["Scuttle", "Scuttle", "Bite", "Bite", "Guard", "Bite"], ["Scuttle", "Bite", "Guard", "Bite", "Scuttle", "Bite"], ["Bite", "Guard", "Scuttle", "Bite", "Guard", "Scuttle"]]

## Cinder Mite [cinder_mite]

Scuttle 2 (Movement: 3), Bite 1, Guard 1. Support can Mend 1 within 2.

HP: determined by the spawning encounter; see its boss/summon rules.

Ordinary-creature-profile dice: [["Scuttle", "Scuttle", "Bite", "Bite", "Guard", "Bite"], ["Scuttle", "Bite", "Guard", "Bite", "Scuttle", "Bite"], ["Bite", "Guard", "Scuttle", "Bite", "Guard", "Scuttle"]]

## Glasswing Moth [glasswing_moth]

3 HP. Needle 1 at range 3 with line of sight. Scuttle 2, Guard 1.

HP: 3

Ordinary-creature-profile dice: [["Needle", "Needle", "Scuttle", "Guard", "Needle", "Scuttle"], ["Scuttle", "Needle", "Guard", "Needle", "Scuttle", "Needle"], ["Needle", "Guard", "Scuttle", "Needle", "Guard", "Scuttle"]]

## Iron Husk [iron_husk]

5 HP. Bash 2 at reach 1. Scuttle 1, Iron Guard +2 Block. No passive armor.

HP: 5

Ordinary-creature-profile dice: [["Scuttle", "Scuttle", "Bash", "Iron Guard", "Bash", "Iron Guard"], ["Iron Guard", "Bash", "Scuttle", "Iron Guard", "Bash", "Scuttle"], ["Bash", "Iron Guard", "Scuttle", "Bash", "Iron Guard", "Scuttle"]]

## Mire Leech [mire_leech]

4 HP. Venom Bite 1 at reach 1; actual HP loss adds Poison 1. Scuttle 2, Guard 1.

HP: 4

Ordinary-creature-profile dice: [["Scuttle", "Scuttle", "Venom Bite", "Venom Bite", "Guard", "Venom Bite"], ["Venom Bite", "Guard", "Scuttle", "Venom Bite", "Scuttle", "Venom Bite"], ["Guard", "Venom Bite", "Scuttle", "Guard", "Venom Bite", "Scuttle"]]

## Movement Creature [movement_creature]

Scuttle 2 (Movement: 3), Bite 1, Guard 1. Support can Mend 1 within 2.

HP: 3

Ordinary-creature-profile dice: [["Scuttle", "Bite", "Bite", "Scuttle", "Guard", "Bite"], ["Bite", "Scuttle", "Bite", "Guard", "Scuttle", "Bite"], ["Scuttle", "Guard", "Bite", "Scuttle", "Bite", "Guard"]]

## Screaming Worm [nugh_worm]

Scuttle 2 (Movement: 3), Bite 1, Guard 1. Support can Mend 1 within 2.

HP: determined by the spawning encounter; see its boss/summon rules.

Ordinary-creature-profile dice: [["Scuttle", "Scuttle", "Bite", "Bite", "Guard", "Bite"], ["Scuttle", "Bite", "Guard", "Bite", "Scuttle", "Bite"], ["Bite", "Guard", "Scuttle", "Bite", "Guard", "Scuttle"]]

## Ash Scavenger [scavenger]

Scuttle 2 (Movement: 3), Bite 1, Guard 1. Support can Mend 1 within 2.

HP: determined by the spawning encounter; see its boss/summon rules.

Ordinary-creature-profile dice: [["Scuttle", "Scuttle", "Bite", "Bite", "Guard", "Bite"], ["Scuttle", "Bite", "Guard", "Bite", "Scuttle", "Bite"], ["Bite", "Guard", "Scuttle", "Bite", "Guard", "Scuttle"]]

## Support Creature [support_creature]

Scuttle 2 (Movement: 3), Bite 1, Guard 1. Support can Mend 1 within 2.

HP: 2

Ordinary-creature-profile dice: [["Mend", "Mend", "Guard", "Scuttle", "Bite", "Mend"], ["Mend", "Guard", "Bite", "Scuttle", "Mend", "Guard"], ["Bite", "Mend", "Scuttle", "Guard", "Mend", "Guard"]]

## The Hollow — action dice and upgrades

[["Advance", "Ashen Chain", "Smoking Strike", "Smoking Strike", "Brace", "Drive Back"], ["Skirmish", "Cinder Brand", "Smoking Strike", "Sweep", "Grave Tithe", "Distort"], ["Advance", "Skirmish", "Cinder Brand", "Sweep", "Drive Back", "Fracture"]]

### Advance

Targeting: Highest HP. Move up to 2 toward the focus hero. Already adjacent: gain 1 Block. No legal route: +1 Block.

Phase upgrade: Movement +1; adjacent Block +1.

### Ashen Chain

Targeting: Furthest hero. Reach 3 · pull up to 1 cells · strip 1 Block. No HP damage.

Phase upgrade: Also applies Rooted 1 until next boss turn.

### Smoking Strike

Targeting: Lowest HP. 1 damage · reach 1. Leave fire under the target. Existing fire detonates for 2 extra damage; ending a hero turn on fire deals 1.

Phase upgrade: Fire detonation damage +1.

### Skirmish

Targeting: Closest hero. Move up to 1, then attack for 1 in reach 1. Recheck targets after moving; if nobody is in reach, no attack.

Phase upgrade: Movement +1.

### Sweep

Targeting: All heroes in reach 1. 1 damage to EVERY hero in reach 1, including Downed heroes. Reactions apply.

Phase upgrade: Reach +1; damage +1 (each hero once).

### Brace

Targeting: Self. +1 Block to self. Expires at next boss turn.

Phase upgrade: Block +1; Die I instead becomes Furnace Roar.

### Drive Back

Targeting: Most Block. 1 damage · reach 1, then force the target away. Collision can cause damage and Stun. Reactions apply.

Phase upgrade: Push distance +1.

### Distort

Targeting: Most active buffs. Reach 2 · Weakness 1 until the next boss turn. No immediate HP damage.

Phase upgrade: Weakness +1.

### Fracture

Targeting: Most active buffs. Reach 1 · target chooses 1 installed ability side(s) to become Blank this encounter. Recorded results stay unchanged.

Phase upgrade: Reach +1; destruction count stays the same.

### Cinder Brand

Targeting: Most enemy HP damage last round. Reach 3 · mark tiles around the target. At next boss turn start, units still on marked tiles take 2 damage. Move away to evade.

Phase upgrade: New warnings become 3×3 squares; detonation damage +1. Already armed cells keep their marked area.

### Grave Tithe

Targeting: All heroes in reach 2. Reach 2 · remove 1 Block from every standing hero. Gain stolen Block up to 2. No HP damage.

Phase upgrade: Steal +1 Block per hero; gain cap +1.

### Furnace Roar

Targeting: All heroes in reach 2. 1 damage to all standing enemies in reach 2, then push survivors up to 1. Reactions apply.

Phase upgrade: Unlocks; reach +1 over its base test value.

## Nu’gh — action dice and upgrades

[["Birth Cry", "Brood Command", "Burrow", "Brood Command", "Gnashing Maw", "Brood Guard"], ["Brood Command", "Brood Command", "Birth Cry", "Burrow", "Gnashing Maw", "Devour Brood"], ["Brood Command", "Birth Cry", "Burrow", "Brood Command", "Devour Brood", "Brood Guard"]]

### Birth Cry

Targeting: Empty nearby cells. Summon 1 worms on empty cells within 2; cap 4 living, 1 HP each. Never on heroes, the boss or other worms.

Phase upgrade: Summon +1 worm(s); Soul Link switches OFF permanently.

### Brood Command

Targeting: All living worms. Each worm: move up to 2 toward a standing hero, then bite if adjacent.

Die: 1, 1, 0, 0, 0, 0. HP loss applies Poison 1 (next activation: damage equal to total Poison, then reduce by 1; applications stack). Reactions apply.

No worms: summon 2 instead. New worms can act after Nu’gh.

Phase upgrade: Worm movement +1; empty-brood summon +1.

### Gnashing Maw

Targeting: Lowest HP. Lowest-HP hero (closest legal fallback) within 1: 1 base + 1 brood pressure damage. No target: RETREAT 1 or gain 1 Block if cornered.

Phase upgrade: Reach +1; brood pressure cap +1.

### Burrow

Targeting: Self. RETREAT up to 1 cells to maximize distance from the nearest hero. No safer route: +1 Block.

Phase upgrade: Retreat +1 and leave 1 worm(s).

### Brood Guard

Targeting: Self. Gain 1 Block + one per living worm, bonus capped at 0.

Phase upgrade: Shield one worm with 1 non-stacking Block.

### Devour Brood

Targeting: Closest living worm. Consume the nearest worm (no Soul Link); heal 1 HP. No worms: summon 2.

Phase upgrade: Gain 1 Block.

## Veyl, the Brass Cantor — action dice and upgrades

[["Gathering Note", "Gathering Note", "Tuning Fork", "Seal the Bell", "Hushed Chime", "Crescendo"], ["Hushed Chime", "Tuning Fork", "Toll of Reckoning", "Seal the Bell", "Gathering Note", "Hushed Chime"], ["Toll of Reckoning", "Hushed Chime", "Tuning Fork", "Toll of Reckoning", "Seal the Bell", "Crescendo"]]

### Gathering Note

Targeting: Self. Gain 2 Resonance, up to 6. No immediate damage. Your own-turn Skills and Defenses calm it before the next boss turn.

Phase upgrade: Resonance gain +1.

### Crescendo

Targeting: Self. Gain 2 Resonance and OPEN THE CORE until next boss turn. Hero Attacks against Veyl gain +1 per hit before Block. Burst now or calm the next Toll.

Phase upgrade: Resonance gain +1; exposed-core Attack bonus +1.

### Seal the Bell

Targeting: Self. Gain 2 Block. Old Block expires next boss turn; this does not close an open core.

Phase upgrade: Block +1.

### Toll of Reckoning

Targeting: All heroes in reach 3. Attack EVERY standing hero within 3 for 1 NOW: 1 base + 1 per 2 Resonance. Spend the entire meter when declared. Reactions apply; the declared hit is fixed. No targets: fallback, keep meter.

Phase upgrade: Reach +1.

### Hushed Chime

Targeting: Most active buffs. Most-buffed hero (closest legal fallback) within 3: 1 damage NOW (1 base + 1 per 3 Resonance). Spend up to 2 Resonance when declared. No target: fallback, keep meter.

Phase upgrade: Reach +1.

### Tuning Fork

Targeting: Furthest hero. Advance up to 1, then attack within 1 for 1. Reactions apply. No reachable target: fallback advance / Block.

Phase upgrade: Movement +1.

## Iron Warden — action dice and upgrades

[["Iron Advance", "Shield Bash", "Iron Advance", "Hammerfall", "Raise Guard", "Crushing Sweep"], ["Shield Bash", "Driving Blow", "Iron Advance", "Raise Guard", "Crushing Sweep", "Raise Guard"], ["Driving Blow", "Shield Bash", "Crushing Sweep", "Iron Advance", "Crushing Sweep", "Raise Guard"]]

### Iron Advance

Targeting: Highest HP. Advance up to 1 toward the party. Occupied tiles block the full 2×2 footprint.

Phase upgrade: Move +1.

### Shield Bash

Targeting: Most Block. Most-Block hero (closest legal fallback) within 1: 1 normal damage. Fully preventing HP loss with Block / Damage Reduction breaks Bulwark and removes his Block. Reactions apply.

Phase upgrade: Damage +1.

### Hammerfall

Targeting: All heroes in reach 1. Attack each opponent within 1 for 2 normal damage. Spread out or guard. One fully defended hero hit breaks Bulwark. Reactions apply.

Phase upgrade: Area reach +1.

### Raise Guard

Targeting: Self. Gain 1 Block. Does not restore a broken Bulwark before his next turn.

Phase upgrade: Block +1; cannot restore Bulwark early.

### Crushing Sweep

Targeting: Marked tiles. Marked cells take 1 damage before his next three dice. The warning is fixed: move a threatened hero out to break Bulwark, or fully guard the impact. Reactions apply; movement Reactions can escape. After every boss turn a sweep is armed if none is already marked. Future warning reach 1.

Phase upgrade: Future warning reach +1; damage +1. Existing warnings do not expand.

### Driving Blow

Targeting: Highest HP. Highest-HP hero (closest legal fallback) within 1: 1 damage. A hero who loses HP is pushed up to 1; occupied cells stop the push. Fully guarding prevents the push and breaks Bulwark.

Phase upgrade: Damage +1; HP-hit push +1.

## Trial special actions

Shield Line: grant up to 2 Block to self and adjacent living enemy allies within 1. This ability will not raise the recipient above 3 Block; it does not remove pre-existing higher Block.

Restitch: heal one living wounded enemy ally within 3 for up to 2 HP, prioritizing most missing HP. Each Mender can use Restitch once per enemy turn.

Mark Charge: focus the furthest hero and mark a fixed cardinal lane of up to 5 tiles, stopping at board edges/barricades. The lane remains fixed. At the next enemy turn start, a living Ram attacks eligible victims still on that lane for 3 normal damage, with Reactions. Killing the source cancels its unresolved charge; empty lanes miss. Repeated marks from that source do not replace the pending lane.

Pilfer: with a legal hero within 2 and carried Run Essence available, take 1 from the Trial purse and store it as that thief's loot. No HP damage. Killing the thief recovers its loot; escaping loses it.

Flee: move up to 2 toward an arena edge away from pursuers. A thief reaching the edge with loot escapes with it. Without loot, it pursues a hero instead.

Needle: ranged attack with the role's ordinary range/line-of-sight checks. Scuttle, Bite, Bash and Guard use the source family/role model. Spirit objectives alter the listed attack/pursuit priorities: spirit first if reachable, otherwise hero fallback.

## Trial terrain and objective objects

Cover reduces normal enemy ranged damage by 1 when the source is farther than 1 and the victim occupies cover. It does not reduce unavoidable damage, melee or Poison.

Barricades block movement and sight. A hero can spend an adjacent Attack result to break one and open that cell. They are not ordinary enemies or free weapon-condition damage. No invented barricade HP counter is added.

Spikes deal 1 unavoidable damage when a living unit lands on a spike cell, including after forced movement. Remaining on that cell does not cause additional periodic ticks.

Ritual stones, the protected spirit and the Trial Hollow core are objects with their specified HP/objective rules. They are not extra enemy turns, ordinary harvest targets or hostile worm ownership entries. Poison/forced movement and enemy-damage conditions must follow the object restrictions.
