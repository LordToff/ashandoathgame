# Normal play and Trials

| Topic | Normal play | Trials |
|---|---|---|
| Party | Individually prepared heroes and owned faces/gear | Two starter classes, optional Soulcaster, legal per-hero kits |
| Starting Memory | Empty | Empty |
| Route | Required Ash Road pre-boss event flow; selected boss; direct creature encounters also available | Five stops before the selected boss; branching battles, events, cache and Camp |
| Health | Encounter/equipment rules | Carries between encounters; printed Camp healing and failure rules apply |
| Encounter reward | Matching creature/boss Essence; normal event supplies/rewards | Run Essence plus matching Trial Forge materials |
| Spendable inventory | Normal Camp's matching Essence and owned copies | Run reward currency separate from the permanent Trial Forge collection |
| Souls | Bound to an individual hero | Trial boss Soul collection and per-recipient ownership stay separate from normal Camp |
| Safe resume | Persistent normal reward ledger; interrupted combat grants no new victory reward | Safe route/reward checkpoints resume; interruption during combat fails the Trial |
| Experiments | No implicit Trial hooks | Ritual/spirit objectives, special roles, Trial Hollow interrupt, forecasts and Trial recipes |
| Optional turn refill | Shared device preference, OFF by default | Same preference and reset rules |

Never combine matching-type Essence with Gold, Salves, Reroll Seals, Soul Fragments, Run Essence, Soul Charges or Trial Forge ingredients. Never silently spend a normal copy/currency while preparing or rewarding a Trial. Merely viewing a recipe or candidate never commits a transaction.
