# Complete ability catalog — 85 face identities

IDs 0–72 are the normal/earned/generated catalog. IDs 73–74 and 81–84 are Weapon projections; 75–80 are temporary Soulcaster spells. IDs are identity references, not extra owned copies.

## 0. Blank

Blank · normal/earned/generated

Reaction when another hero is attacked: become the target if adjacent to the boss. You must be a legal target.

Blanks have no starting effect. An equipped Memory may provide a conversion; Soulcaster enables Gather / Manifest. The separate sandbox can test Move 2 with 1 use(s).

## 1. Strike

Attack · normal/earned/generated

Reaction before a lethal Attack: stay at 1 HP instead, gain Stunned, then blank this face. Prototype sets aside your first available result.

Deal 1 damage to an adjacent unit.

## 2. Step

Movement · normal/earned/generated

Gain Damage Reduction 1 and Weakness 1 until your next turn. Unavoidable damage bypasses reduction.

Move up to 1 orthogonal spaces. Occupied cells block the path.

## 3. Stride

Movement · normal/earned/generated

Reaction during an enemy Attack: deal your actual HP damage taken this round to the boss (cap 3), then blank this face. If unused, take 1 unavoidable damage at next turn start.

Move up to 3 spaces in a straight line. No turning or passing through units.

## 4. Guard

Defense · normal/earned/generated

Channel: at each maintained turn start, heal 1 if no HP damage got through. HP damage breaks this Channel and blanks it.

Gain 1 Block. Unspent Block expires at your next turn.

## 5. Reaction

Defense - Reaction · normal/earned/generated

Gain Numeric +1 Block. Prototype timing: at your turn end, lose 1 HP if Block remains.

When personally attacked, gain 2 Block before the hit. No movement.

## 6. Focus

Skill · normal/earned/generated

Prototype: gain Numeric Block. Until your next turn, an adjacent boss Attack causing HP loss gives the boss Weakness 1 until its turn ends.

Click another ready die or held Reaction to reroll it. Resolve its new result next, or decline it.

Works after other actions. Uses this Focus face, not a reroll charge. Locked faces cannot be rerolled.

## 7. First Aid

Skill · normal/earned/generated

Prototype: gain Numeric Block, then burn up to 2 Block; each deals normal damage to every adjacent unit, including allies. Choose how much to burn.

Heal yourself or an ally within 1 for 1 HP. A Downed ally revives as Broken.

## 8. Shove

Skill · normal/earned/generated

Tabletop variant: leap up to 2 orthogonally over units, never land occupied. If ending adjacent to the boss, your next Numeric damage this turn gets +1.

Push an adjacent unit up to 1 spaces away. No collision damage.

## 9. Gambler's Coin

Skill · normal/earned/generated

Arm Numeric with x0 and x2. Roll again to gain 1 Gold and blank this face for the fight.

First use: arm Numeric ×0 / ×2. Next use: gain 1 Gold and turn this face Blank.

Non-rerollable. Gold has no shop in this encounter.

## 10. Weak Point

Skill · normal/earned/generated

Gain a personal backstab marker through next round. Your next adjacent Attack from below the north-facing boss repeats once, with fresh Numeric rolls for each resolution.

Arm Weak Point through the end of the next 1 round(s). Your next Attack from the boss’s southern edge repeats 1 extra time(s).

The gold marker stays until used or expired.

## 11. Conjure

Skill · normal/earned/generated

Copy another visible immediate hero face. Select its hero and die; resolve the copy now. No setup/copy loops.

Copy another visible immediate hero ability within 99. Choose its hero and die, then resolve the copy.

No setup or copy chains. Non-rerollable.

## 12. Blessing of Recovery

Skill · normal/earned/generated

Choose a hero and a specific Blank slot: install Recovery there. Recovery heals Numeric at range 1. After two placements this face becomes Blank.

Install Recovery on a chosen Blank belonging to a hero. Recovery heals a rolled value at range 1.

After 2 placements, this face becomes Blank.

## 13. Clairvoyance

Skill · normal/earned/generated

Prototype: when rolled, gain 1 Action Reroll (cap 1). The bank begins with 1, so save this for replenishment.

When rolled, gain 1 Action Reroll, up to the bank cap of 1. A full bank gains nothing.

## 14. Forgotten Strength

Skill · normal/earned/generated

Tabletop variant: your next Numeric damage this turn gets +1. No party-wide buff or backlash.

Your next rolled damage this turn gets +1.

## 15. Passing Grace

Skill · normal/earned/generated

Heal another hero within 3 for Numeric, then pass this face to a Blank on that hero. No self-target; the source becomes Blank.

Heal another hero within 3 for a rolled value. Move this face to a Blank on that hero.

Cannot heal yourself. Non-rerollable.

## 16. Borrow Shape

Skill · normal/earned/generated

Copy any hero’s face-up die result, even spent or held, onto this die and resolve it next. Borrow Shape and Red Tile cannot be copied.

Choose any of the nine face-up hero dice, including spent or held results. Copy its result onto this die and resolve it next (or hold its Reaction). The source die is unchanged. Borrow Shape and Red Tile are excluded to prevent loops and copying a locked penalty.

## 17. Numeric Echo

Skill · normal/earned/generated

Roll and store one ordinary Numeric value. It replaces your next Numeric roll. A second stored value is not allowed.

Roll and store one ordinary value. Use it instead of your next Numeric roll. Only one value can be stored.

## 18. Lethargic Bind

Skill · normal/earned/generated

Choose a boss die and face. Until your next turn, that face rolls as Bound (no action); you suffer 1 normal damage each time it triggers.

Bind a chosen boss die and face until your next turn. Each matching roll is skipped, but you take 1 normal damage.

## 19. Restore

Skill · normal/earned/generated

Heal another hero within 3 for Numeric, minimum 1. Cannot target yourself. Gambler x0 stays zero.

Heal another hero within 3 for a rolled value, at least 1. Clear sight required. Gambler ×0 stays zero.

## 20. Focus Numeric

Skill · normal/earned/generated

Your next Numeric roll this turn treats Blank as 1, then this benefit ends.

Your next Numeric roll this turn treats Blank as 1.

## 21. Mark Prey

Skill · normal/earned/generated

Mark the boss until round end. The next damaging Attack when it has zero Block adds 1 damage, then removes the mark.

Mark the boss until round end. Its next damaging Attack hit while at zero Block gains 1 damage, then removes the mark.

## 22. Last Word

Skill · normal/earned/generated

After all your other non-Blank dice resolve, deal 1 unavoidable damage to the boss. Prototype range: visible anywhere.

After your other non-Blank dice are spent, deal 1 unavoidable damage to the boss.

## 23. Second Chance

Skill · normal/earned/generated

Skip another unresolved non-Blank die, then repeat one already spent immediate face. Copy/repeat faces cannot chain into themselves.

Skip another unresolved non-Blank die. Repeat a different, already-spent immediate ability. No repeat or copy chains.

## 24. Spiral Instability

Skill · normal/earned/generated

Roll this die until an Attack appears, then resolve it twice at random legal adjacent units, including allies. No Attack on this die: no effect.

Choose an Attack from this die and resolve it 2 times at random legal targets, including allies. No Attack on this die means no effect.

## 25. Contained Power

Skill - Channel · normal/earned/generated

Channel: after maintaining at turn start, each future Blank grants 1 Block and each non-Blank adds Numeric +1 for that turn, capped +2. HP damage breaks it, deals 2 more and leaves a Red Tile. Prototype limit: one active Channel per hero; a second cannot replace it.

Maintain: future Blank rolls grant 1 Block; other rolls add +1 to Numeric, capped at +2.

HP loss breaks it, causes 2 normal backlash damage and leaves a Red Tile.

## 26. Corruption Conversion

Skill · normal/earned/generated

Prototype on resolution: choose an unresolved Blank die, then choose an installed ability on it and resolve that face. This face becomes a locked Red Tile for the fight.

Choose an unresolved Blank die, then an ability installed on it. Resolve that result. This Conversion face becomes a locked Red Tile.

## 27. Blood Bargain

Skill · normal/earned/generated

Empower the next two Attacks against the boss by +1 damage. After the second, take 1 unavoidable damage.

The next 2 Attacks against the boss gain +1 damage. After the last, you take 1 unavoidable damage.

## 28. Target Override

Skill - Reaction · normal/earned/generated

Reaction when personally targeted: force a different legal adjacent hero to be targeted. With no alternative the original target remains.

When personally targeted, redirect to a different legal adjacent hero. With no alternative, the original target remains.

## 29. Debt

Skill · normal/earned/generated

Your next Attack or Defense this turn gets +2 value. At your next turn, the first such face gets −2 value (minimum 0).

Next Attack or Defense this turn: +2. At your next turn, your first such face suffers −2, minimum zero.

## 30. Ill Omen

Skill · normal/earned/generated

Prototype resolution choice: modify another unresolved Attack/Defense. d6: 1 gives −1, 2–4 gives +1, 5 gives Pierce 2 (Defense +2 Block), 6 repeats an Attack or doubles Defense Block.

Modify an unresolved Attack or Defense with a random bonus, penalty, Pierce or repeat. Pick the affected die. See More rules for the six outcomes.

## 31. Stonewake

Skill - Channel · normal/earned/generated

Prototype Channel: gain 2 Block. While maintained, explicitly preserve existing Block at turn start and add 1 (cap 8). Any HP loss or 2 cumulative Block lost before your next turn breaks this Channel. End voluntarily to reroll the die. Prototype limit: one active Channel per hero; a second cannot replace it.

Gain 2 Block. Maintain: preserve Block and add 1, up to 8.

Any HP loss or 2 cumulative Block lost before your next turn interrupts this Channel.

## 32. Oath of Smoke

Skill · normal/earned/generated

Prototype: resolve another rolled Step, Stride or Guard now; store it as a Reaction until the next shared roll. Movement reaction steps 1; Defense grants 1 Block.

Resolve another rolled Step, Stride or Guard now. Then store it as a Reaction until the next shared roll.

## 33. Bone Mutation

Skill · normal/earned/generated

Choose a Blank on one of your dice and replace it with Bone for this fight. Bone grants 1 Block, then optionally steps 1.

Install Bone on one of your Blanks for this fight. Bone gains 1 Block and may step 1.

## 34. Strike Numeric

Attack · normal/earned/generated

Adjacent unit: roll Numeric and deal that much damage.

Roll for damage against an adjacent unit.

## 35. Short Shot

Attack · normal/earned/generated

Target a visible unit within 2. Damage capped at 2 per resolution, including Mark Prey; the mark is consumed on a damaging hit. Units block sight; no diagonal corner shooting.

Roll for damage against a visible unit within 2. Final damage is capped at 2, including Mark Prey.

## 36. Hooked Slash

Attack · normal/earned/generated

Catalog variant: adjacent Numeric Attack. If at least 2 HP damage is dealt, gain that much Block.

Roll for damage against an adjacent unit. At least 2 HP lost: gain that HP loss ×1 as Block.

## 37. Piercing Thrust

Attack · normal/earned/generated

Adjacent Numeric Attack. Bypass 1 Block without destroying the bypassed portion.

Roll for damage against an adjacent unit. Bypass 1 Block; the bypassed Block remains after this hit.

## 38. Cleave

Attack · normal/earned/generated

Adjacent Numeric Attack. A second enemy adjacent to that target takes 1. With no secondary enemy, there is no splash hit.

Roll for damage against an adjacent unit. Also deal 1 damage to one other enemy adjacent to the target.

## 39. Flanking Blow

Attack · normal/earned/generated

Prototype: adjacent Numeric Attack; add 1 when standing below the north-facing boss. Rear means its southern edge.

Roll for damage against an adjacent unit. Add 1 when standing at the boss’s southern edge.

## 40. Break Rhythm

Attack · normal/earned/generated

Adjacent Numeric Attack. If you break existing Block and deal HP damage, delay an upcoming boss activation one initiative slot when possible; normal initiative returns next round.

Roll for damage against an adjacent unit. Break existing Block and damage HP to delay an upcoming boss activation by 1 slot(s).

## 41. Engrave

Attack · normal/earned/generated

Prototype adjacent Numeric Attack. After dealing HP damage, once per hero turn, fill one Blank on this die with Engrave, up to 3 copies. Never overwrites abilities. 3 copies: +1 damage; no further scaling.

Roll for damage against an adjacent unit. On HP damage, grow on this die up to 1 time(s) per hero turn, capped at 3 copies.

At 6 copies: +1 damage. Never overwrites another ability.

## 42. Guard Numeric

Defense · normal/earned/generated

Gain Block equal to a Numeric roll.

Roll a value and gain that much Block.

## 43. Brace Hero

Defense · normal/earned/generated

If at zero Block, gain 3; otherwise gain 1.

At zero Block: gain 3. Otherwise: gain 1.

## 44. Shield Wall

Defense - Reaction · normal/earned/generated

Reaction when an ally within 2 is attacked: give both that hero and yourself 1 Block before the hit.

When an ally within 2 is attacked, give them 1 Block and yourself 1 before the hit. Clear sight required.

## 45. Taunt

Defense - Reaction · normal/earned/generated

Reaction when another hero is attacked: become the target if adjacent to the boss. You must be a legal target.

When another hero is attacked, take their place if you are a legal target within 1. Cannot redirect Sweep or Furnace Roar.

## 46. Defy Death

Defense - Reaction · normal/earned/generated

Reaction before a lethal Attack: stay at 1 HP instead, gain Stunned, then blank this face. Prototype sets aside your first available result.

Before a lethal Attack, remain at 1 HP instead and gain Stunned. This face becomes Blank.

## 47. Bulwark

Defense · normal/earned/generated

Gain Damage Reduction 1 and Weakness 1 until your next turn. Unavoidable damage bypasses reduction.

Gain Damage Reduction 1 and Weakness 1 until your next turn. Unavoidable damage bypasses reduction.

## 48. Echo of Pain

Defense - Reaction · normal/earned/generated

Reaction during an enemy Attack: deal your actual HP damage taken this round to the boss (cap 3), then blank this face. If unused, take 1 unavoidable damage at next turn start.

During an enemy Attack, deal the HP damage you took this round to the boss, capped at 3. This face becomes Blank.

Unused: take 1 unavoidable damage at your next turn.

## 49. Last Pulse

Defense - Channel · normal/earned/generated

Channel: at each maintained turn start, heal 1 if no HP damage got through. HP damage breaks this Channel and blanks it. Prototype limit: one active Channel per hero; a second cannot replace it.

Maintain: heal 1 at your turn start. Any HP loss interrupts the Channel and turns this face Blank.

## 50. Black Oath

Defense · normal/earned/generated

Gain Numeric +1 Block. Prototype timing: at your turn end, lose 1 HP if Block remains.

Gain a rolled value +1 Block. At your turn end, lose 1 HP if any Block remains.

## 51. Wither Ward

Defense · normal/earned/generated

Prototype: gain Numeric Block. Until your next turn, an adjacent boss Attack causing HP loss gives the boss Weakness 1 until its turn ends.

Gain rolled Block. Until your next turn, an adjacent boss Attack that removes HP gives the boss Weakness 1.

## 52. Ember Burst

Defense · normal/earned/generated

Prototype: gain Numeric Block, then burn up to 2 Block; each deals normal damage to every adjacent unit, including allies. Choose how much to burn.

Gain rolled Block, then burn up to 2 Block. Each burned point deals 1 damage to every other unit within 1, including allies.

## 53. Leap of Echoes

Movement · normal/earned/generated

Tabletop variant: leap up to 2 orthogonally over units, never land occupied. If ending adjacent to the boss, your next Numeric damage this turn gets +1.

Leap up to 2 spaces, over units but never onto them. End within 1 of the boss to gain +1 on your next rolled damage this turn.

## 54. Bone

Skill · normal/earned/generated

Gain 1 Block and optionally step 1.

Gain 1 Block and optionally step 1.

## 55. Recovery

Skill · normal/earned/generated

Heal yourself or an adjacent hero for Numeric.

Heal yourself or an ally within 1 for a rolled value.

## 56. Red Tile

Penalty · normal/earned/generated

Inert, non-rerollable, not a Blank, locked for this encounter.

No effect. Locked: cannot be rerolled and does not count as a Blank.

## 57. Ashstep

Movement · normal/earned/generated

Slip through ash: move up to 2 orthogonal spaces, turning allowed, then gain 1 Block. Cannot pass through units.

Move up to 2 spaces, turning allowed, then gain 1 Block. Occupied cells block the path.

## 58. Oathbound Exchange

Movement · normal/earned/generated

Swap positions with a living standing ally within 3 and clear sight. Both heroes gain 1 Block. Cannot swap with the boss or a Downed hero.

Swap with a standing ally within 3 and clear sight. Both gain 1 Block. Rooted prevents the swap.

## 59. Summon Nu’gh

Skill · normal/earned/generated

Summon one friendly Nu’gh on an adjacent empty tile: 1 HP, Move 2, bite range 1, Numeric 1,1,0,0,0,0. HP damage applies Poison 1. Acts after its owner’s turn. While alive, all copies become Command Nu’gh: activate it immediately as well. One worm per hero.

Summon a friendly Nu’gh on an adjacent empty cell: 1 HP, Move 2, reach 1. Numeric bite: 2 successful sides of six, 1 damage; HP damage applies Poison 1. Acts after owner’s turn. While alive: Command grants an immediate extra activation. One per hero across all copies.

## 60. Bone Growth

Skill · normal/earned/generated

Bone. Gain 1 Block and optionally Move 1.

Bone. Gain 1 Block and optionally Move 1.

## 61. Bone Strike

Attack · normal/earned/generated

Bone. Adjacent enemy: deal 1 damage per Bone result rolled this turn, spent results count; this face counts if rolled.

Bone. Adjacent enemy: deal 1 damage per Bone result rolled this turn, spent results count; this face counts if rolled.

## 62. Bone Guard

Defense · normal/earned/generated

Bone. Gain 1 Block per Bone result rolled this turn, spent results count; this face counts if rolled.

Bone. Gain 1 Block per Bone result rolled this turn, spent results count; this face counts if rolled.

## 63. Shared Remedy

Skill · normal/earned/generated

Healing. Heal yourself 1. Only if HP was actually restored, choose an ally within 2 to heal 1.

Healing. Heal yourself 1. Only if HP was actually restored, choose an ally within 2 to heal 1.

## 64. Sorrow’s Offering

Skill · normal/earned/generated

Optionally lose 1 HP, then choose an ally within 2: +2 Block or +1 damage on their next Attack. Decline spends the face without effect.

Optionally lose 1 HP, then choose an ally within 2: +2 Block or +1 damage on their next Attack. Decline spends the face without effect.

## 65. Shared Burden

Skill · normal/earned/generated

Choose another of your results rolled this round, spent or ready. An ally within 2 spends a ready die to resolve a copy immediately as a single-action interrupt. Their other dice and normal turn are unchanged. No Shared Burden copy loops.

Choose another of your results rolled this round, spent or ready. An ally within 2 spends a ready die to resolve a copy immediately as a single-action interrupt. Their other dice and normal turn are unchanged. No Shared Burden copy loops.

## 66. Retreat

Movement · normal/earned/generated

Move up to 2. If you end farther from every living enemy than at the start, gain 1 Block.

Move up to 2. If you end farther from every living enemy than at the start, gain 1 Block.

## 67. Momentum Strike

Attack · normal/earned/generated

After moving 2 spaces this turn: adjacent enemy takes 1 damage. After 3+ spaces: Numeric +1 damage instead.

After moving 2 spaces this turn: adjacent enemy takes 1 damage. After 3+ spaces: Numeric +1 damage instead.

## 68. Evasive Counter

Defense - Reaction · normal/earned/generated

Reaction when targeted: +1 Block before the Attack. If it removes no HP, optionally Move 1 after the entire Attack resolves.

Reaction when targeted: +1 Block before the Attack. If it removes no HP, optionally Move 1 after the entire Attack resolves.

## 69. Ember Cut

Attack · normal/earned/generated

Adjacent enemy: deal 2 damage. If HP is lost, gain 1 Block.

Adjacent enemy: deal 2 damage. If HP is lost, gain 1 Block.

## 70. Brood Needle

Attack · normal/earned/generated

Enemy in clear sight within 2: deal 1 damage. If HP is lost, apply Poison 1.

Enemy in clear sight within 2: deal 1 damage. If HP is lost, apply Poison 1.

## 71. Quiet Note

Skill · normal/earned/generated

Heal yourself 1 HP and clear your Weakness.

Heal yourself 1 HP and clear your Weakness.

## 72. Iron Shelter

Defense · normal/earned/generated

Gain 2 Block, or 3 Block if you already have Block.

Gain 2 Block, or 3 Block if you already have Block.

## 73. Jab

Attack · weapon projection

After moving at least 2 spaces this own turn, deal 1 damage to an enemy within 2. Once per own turn; spends this rolled die.

After moving at least 2 spaces this own turn, deal 1 damage to an enemy within 2. Once per own turn; spends this rolled die.

## 74. Crack

Attack · weapon projection

After another Attack this own turn, remove up to 2 Block from an adjacent enemy. No HP damage. Once per own turn; spends this rolled die.

After another Attack this own turn, remove up to 2 Block from an adjacent enemy. No HP damage. Once per own turn; spends this rolled die.

## 75. Wraith Exchange

Movement · Soulcaster encounter spell

Swap with a standing ally within 4. Then each hero may Move 1. Rooted prevents the swap; the follow-up steps stay Move 1.

Swap with a standing ally within 4. Then each hero may Move 1. Rooted prevents the swap; the follow-up steps stay Move 1.

## 76. Soul Harvester

Attack · Soulcaster encounter spell

Spend 1 Soul Charge to deal 1 normal Attack damage to an enemy within 3. Killing an enemy creature or boss grants 2 Soul Charges, up to 3.

Spend 1 Soul Charge to deal 1 normal Attack damage to an enemy within 3. Killing an enemy creature or boss grants 2 Soul Charges, up to 3.

## 77. Mirror of the Damned

Defense - Reaction · Soulcaster encounter spell

Reaction: when you or an ally within 2 is attacked, give the target 2 Block. If the entire Attack causes no HP loss, deal 1 normal damage to its attacker.

Reaction: when you or an ally within 2 is attacked, give the target 2 Block. If the entire Attack causes no HP loss, deal 1 normal damage to its attacker.

## 78. Grave Stitch

Skill · Soulcaster encounter spell

Heal yourself or an ally within 2 for 2 HP, then turn this spell side back into Blank. Can revive a Downed hero or heal the living Spirit.

Heal yourself or an ally within 2 for 2 HP, then turn this spell side back into Blank. Can revive a Downed hero or heal the living Spirit.

## 79. Hoarded Omen

Skill · Soulcaster encounter spell

Choose yourself or a standing ally within 3. On their next turn they may save one ordinary ready ability. Its original die stays aside and the saved result is ready on their turn in the following round. No Reactions, Channels, when-rolled results, penalties, Blanks or Hoarded Omen.

Choose yourself or a standing ally within 3. On their next turn they may save one ordinary ready ability. Its original die stays aside and the saved result is ready on their turn in the following round. No Reactions, Channels, when-rolled results, penalties, Blanks or Hoarded Omen.

## 80. Fatebreaker

Skill - When rolled · Soulcaster encounter spell

When rolled: gain 1 Action Reroll, up to its normal cap, then reroll one eligible unresolved enemy die. Each enemy die can be rerolled once per shared round. If none is eligible, only the Action Reroll is gained.

When rolled: gain 1 Action Reroll, up to its normal cap, then reroll one eligible unresolved enemy die. Each enemy die can be rerolled once per shared round. If none is eligible, only the Action Reroll is gained.

## 81. Poke

Attack · weapon projection

Deal 1 damage to an adjacent enemy after you have dealt actual enemy HP damage this own turn. Once per own turn; spends this rolled die.

Deal 1 damage to an adjacent enemy after you have dealt actual enemy HP damage this own turn. Once per own turn; spends this rolled die.

## 82. Poison Poke

Attack · weapon projection

Poke for 1 damage. If the target loses HP, apply Poison 1. Requires earlier enemy HP damage this own turn. Once per own turn; spends this rolled die.

Poke for 1 damage. If the target loses HP, apply Poison 1. Requires earlier enemy HP damage this own turn. Once per own turn; spends this rolled die.

## 83. Heavy Poke

Attack · weapon projection

Poke for 2 damage, then pay 1 HP unless combat ended. Requires earlier enemy HP damage this own turn. Once per own turn; spends this rolled die.

Poke for 2 damage, then pay 1 HP unless combat ended. Requires earlier enemy HP damage this own turn. Once per own turn; spends this rolled die.

## 84. Oath Cut

Attack · weapon projection

Deal 1 damage to an adjacent enemy. Spends this rolled die. Oathblade gives all your Attack faces Pierce 1.

Deal 1 damage to an adjacent enemy. Spends this rolled die. Oathblade gives all your Attack faces Pierce 1.
