# Ash & Oath — remake kit

This is the complete implemented-mechanics handoff for v0.46. Remake the entire presentation and choose a new engine/art style freely. There are no directions for editing the old HUD or art, and no inherited visual-style restrictions.

Read in this order:

1. CORE_MECHANICS.md — the current decisions and rules that must survive a remake.
2. ALL_GAME_RULES.md or ALL_GAME_RULES.pdf — the detailed mechanics manual, including timing, all four bosses, progression, Trials and the 85-entry face catalog.
3. RULE_DATA.json — exact exported ability, item, enemy, crafting and balance data from the source.
4. reference-model/ — optional original gameplay code for precise formulas, validation, save semantics and edge cases. It is reference material; your remake does not have to use Godot. This directory is not a standalone runnable project.

ABILITY_CATALOG.md, EQUIPMENT.md and PROGRESSION_DATA.md are shorter topic references. NORMAL_VS_TRIALS.md prevents mixing their currencies/ownership. NEXT_CHAT_PROMPT.txt is ready to paste into your next chat.

Scope: all normal play, Trials, four bosses, nine creature/reward families, five Trial enemy roles, 73 normal/earned/generated face IDs plus six weapon projections and six Soulcaster spells, 339 balance-schema entries, equipment, recipes, events and optional rules. Legacy compatibility parameters exist in the balance schema; equipment-authoritative current rules take precedence over obsolete fallback descriptions.

Provenance: source be9f5c2675a45d989976334c7f20c7e186d4a5ca, repository https://github.com/LordToff/ashandoathgame . Current playable reference: https://lordtoff.github.io/ashandoathgame/?v=0.46 . Source code is included only as a mechanics reference, not instructions to continue the old visual design.

The detailed manual is adapted from the implemented v0.46 rulebook: presentation-only chapters and obsolete navigation descriptions are removed, while mechanics are retained. CORE_MECHANICS.md and current exported definitions settle any ambiguous historical wording; the executable reference model settles remaining edge cases. Prototype interpretations are identified in the face descriptions. This kit does not invent the original PDFs' unfinished services, Hunt systems or other unimplemented candidates.
