# Equipment and construction data

These are the current shared equipment definitions. Body and Weapon limits are total counts across the three dice; Soul Blank minima apply to each die.

## Bodies

### Broken Body

Defense 0–3 · Movement 0–3 · Skill 0–3 across all three dice. Attack limits come from your Weapon.

limits: {"Defense": [0, 3], "Movement": [0, 3], "Skill": [0, 3]}

### Fleet Body

Defense 0–2 · Movement 0–4 · Skill 0–3 across all three dice. Movement uses its printed distance. Attack limits come from your Weapon.

limits: {"Defense": [0, 2], "Movement": [0, 4], "Skill": [0, 3]}

### Stone Body

Defense 0–4 · Movement 0–2 · Skill 0–3 across all three dice. Attack limits come from your Weapon.

limits: {"Defense": [0, 4], "Movement": [0, 2], "Skill": [0, 3]}

## Souls

### No Soul

6 HP · minimum 2 Blanks on every die. No strong Soul effect.

blanks: 2; hp: 6

### Ash Road Soul

6 HP · minimum 3 Blanks per die. Last Ember: once per encounter, lethal enemy damage leaves you at 1 HP.

blanks: 3; hp: 6

### Beginning Soul

6 HP · minimum 2 Blanks on every die. Last Ember: once per encounter, lethal enemy damage leaves you at 1 HP. Does not prevent voluntary HP costs.

blanks: 2; hp: 6

### Warden Soul

6 HP · minimum 3 Blanks per die. Keep up to 2 Block at own-turn start. Movement abilities travel 1 less, minimum 1.

blanks: 3; hp: 6

### Echo Soul

6 HP · minimum 3 Blanks per die. First Skill each own turn readies +1 next-Attack damage. Begin with 0 Action Rerolls.

blanks: 3; hp: 6

### Cinder Soul

6 HP · minimum 3 Blanks per die. Your first HP-damaging Attack each own turn adds Poison 1. Begin each encounter with Poison 1.

blanks: 3; hp: 6

### Brood Soul

5 HP · minimum 3 Blanks per die. First Poison you apply each own turn spreads Poison 1 to another adjacent enemy.

blanks: 3; hp: 5

### Soulcaster

6 HP · minimum 4 Blanks on every die. Gather Soul Charges or Manifest encounter spells using rolled Blanks. Charge cap 3; spell cap 4. Manifest costs charges + 1 HP. New spells activate only when rolled on a later turn.

blanks: 4; hp: 6

## Weapons

### Unarmed

Attack faces: minimum 0 / maximum 0. Equip a Weapon to use Attack faces.

max: 0; min: 0; modifiers: {}; replacements: []

### Dagger

Attack faces: minimum 2 / maximum 5. Replace 1 basic Strike → Poke (1 damage after earlier enemy HP damage). All-Attack passive: none.

max: 5; min: 2; modifiers: {}; replacements: [81]

### Hammer

Attack faces: minimum 2 / maximum 8. Replace 1 basic Strike → Crack (remove 2 adjacent Block after another Attack). All-Attack passive: none.

max: 8; min: 2; modifiers: {}; replacements: [74]

### Heavy Dagger

Attack faces: minimum 2 / maximum 6. Replace 1 basic Strike → Heavy Poke (2 damage, then pay 1 HP). All-Attack passive: none.

max: 6; min: 2; modifiers: {}; replacements: [83]

### Oathblade

Attack faces: minimum 3 / maximum 6. Replace 3 basic Strikes → Oath Cut (1 adjacent damage each). Passive: ALL your Attack faces gain Pierce 1, including other equipped Attacks. Replacements spend rolled dice.

max: 6; min: 3; modifiers: {"pierce": 1}; replacements: [84, 84, 84]

### Spear

Attack faces: minimum 2 / maximum 6. Replace 1 basic Strike → Jab (range 2; move 2 first). All-Attack passive: none.

max: 6; min: 2; modifiers: {}; replacements: [73]

### Poison Dagger

Attack faces: minimum 2 / maximum 5. Replace 1 basic Strike → Poison Poke (1 damage; HP loss adds Poison 1). All-Attack passive: none.

max: 5; min: 2; modifiers: {}; replacements: [82]

## Memories

### Memory of the First Step

Spend one rolled Blank as Move 1, once per own turn. The installed side remains Blank.

distance: 1; mode: move

### Glasswing Memory

Spend one rolled Blank to blink up to 2 orthogonal spaces, once per own turn. Landing must be empty; Rooted prevents this.

distance: 2; mode: blink

### Memory of Hearth

Spend one rolled Blank to heal yourself 1 HP, once per own turn. Cannot revive yourself.

distance: 0; mode: heal

### Ironbound Memory

Spend one rolled Blank to gain 2 Block, once per own turn.

distance: 0; mode: block

### Memory of the Mire

Spend one rolled Blank to heal yourself 1 HP, once per own turn. Cannot revive yourself.

distance: 0; mode: heal

### Memory of Wind

Spend one rolled Blank as Move 2, once per own turn.

distance: 2; mode: move

## Additional Trial Memories

### No Memory

Empty for the first encounter. Equip an earned Memory later for a passive effect.

### Memory of the First Step

Spend one rolled Blank as Move 1, once per own turn. The installed side remains Blank.

### Glasswing Memory

Spend one rolled Blank to blink up to 2 orthogonal spaces, once per own turn. Landing must be empty; Rooted prevents this.

### Memory of Guard

When Block prevents all HP damage from an enemy Attack, your next Attack against an enemy deals +1 damage.

### Memory of Hearth

Spend one rolled Blank to heal yourself 1 HP, once per own turn. Cannot revive yourself.

### Ironbound Memory

Spend one rolled Blank to gain 2 Block, once per own turn.

### Memory of the Mire

Spend one rolled Blank to heal yourself 1 HP, once per own turn. Cannot revive yourself.

### Memory of Shelter

Your first own-turn Defense ability grants 1 extra Block.

### Memory of Momentum

Move at least 2 spaces during your turn: your next Attack against an enemy deals +1 damage, once that turn.

### Memory of Venom

Your first own-turn Attack that damages an enemy adds Poison 1. Healing you receive restores 1 less HP.

### Memory of Wind

Spend one rolled Blank as Move 2, once per own turn.
