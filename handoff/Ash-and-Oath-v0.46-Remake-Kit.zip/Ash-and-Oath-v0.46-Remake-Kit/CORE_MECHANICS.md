# Ash & Oath — mechanics contract for a complete remake

Snapshot: implemented v0.46, 16 November 2026. Source commit: be9f5c2675a45d989976334c7f20c7e186d4a5ca.

## Purpose and authority

This kit transfers the game design and implemented behavior so a new chat can remake the whole game. The new implementation can use a different engine, interface, HUD, art, palette, animation and layout. None of the previous visual directions is a requirement. This is a mechanics specification, not instructions for replacing parts of the existing interface.

Preserve the mechanics below unless the user explicitly changes them. The source model and the exported rule data are the precise reference for edge cases and numbers. The current rulebook supplies plain-language explanations. Historical design documents and old patch notes are not additional active rules. Many balance values are provisional prototype decisions, not immutable tabletop canon.

The kit covers BOTH normal play and Trials, all four implemented bosses, all 85 face identities, normal and Trial progression, crafting and optional rules. Trials are a separate experimental mode, not a replacement for the normal game.

## The four equipment layers — current decisions

- Body: only minimum/maximum Defense, Movement and Skill faces, counted across a hero's three dice. Body does not set Attack limits, maximum HP, minimum Blanks or movement distance.
- Soul: maximum HP, minimum Blanks on EACH die, and a strong printed effect. Souls belong to individual heroes; ownership must not become a party-wide unlock.
- Memory: one passive modifier slot. The first encounter starts EMPTY. Many Memories offer another use for a rolled Blank. Memories do not inherently change maximum HP. There are no extra passive/path/edge slots.
- Weapon: minimum/maximum total Attack faces; 1–3 designated basic Strike sides become weapon-specific rolled attacks; some weapons modify ALL Attack faces. Preserve the remaining basic Strikes and physical side/copy ownership. These replacements must roll and spend a die when used.

Beginning Soul is 6 HP, minimum 2 Blanks per die, and Last Ember: once per encounter, lethal enemy damage leaves the hero at 1 HP. It does NOT inherently provide Blank movement. Memory of the First Step spends one rolled Blank as Move 1 once per own turn. The optional global Blank → Move 1 rule is a separate setting.

Dagger's Poke is a ROLLED attack face, not a free extra action. It deals 1 damage to an adjacent enemy only after that hero already caused actual enemy HP damage during this own turn, once per own turn. It spends its die. Blocked hits, ally damage, another hero's damage and attacks on objective objects do not satisfy its requirement.

Spear replaces one Strike with Jab: after moving at least 2 spaces this own turn, deal 1 damage to an enemy within 2, once per own turn, spending that rolled die. Hammer replaces one Strike with Crack: after another Attack this own turn, remove up to 2 adjacent enemy Block, dealing no HP damage, once per own turn, spending that rolled die. Oathblade replaces three Strikes with Oath Cut and grants ALL that hero's Attack faces Pierce 1.

## Core battle structure

Three individually built heroes, currently named Vesper, Rook and Wren, fight on a 9×9 grid. Each has three six-sided Action Dice, HP, Block, statuses, a reroll bank and their own equipment. The main boss occupies a 2×2 footprint; ordinary creatures and Trial objective objects use their model-defined one-cell footprints. Art size is never a hitbox.

Initiative is rolled once and stays in a fixed order. All available Action Dice roll together at shared round start. A hero's individual turn does not automatically roll three fresh dice. The hero resolves available results in any order, subject to mandatory pending choices and forced-result rules. Immediate recovery is an explicit exception with fresh dice.

An Attack/targeted effect chooses an ability and a legal target; movement chooses a legal destination; self Defense/effects resolve on use. Invalid actions spend nothing. Reactions and effect-specific choices remain mandatory where the rules require them. Preserve direct action semantics; ordinary attacks do not need an additional generic confirm operation.

The encounter ends when the required boss/objective is defeated, or the party has no hero alive above zero HP. Trial ritual/spirit objectives have their own victory conditions. Nu'gh's defeat also clears his remaining hostile worms. Multiple hits resolve separately, with range, death, sight, riders and reactions rechecked at their actual points in the sequence.

## Rerolls, Blanks and optional rules

Default: one starting banked Action Reroll per hero, bank cap 1, no automatic refill. A paid reroll costs a charge and can land on the same face. It does not automatically use its new result. Focus instead spends its own rolled ability and forces the eligible rerolled result next, or stores it if it is a Reaction. Spent dice, Channels and printed non-rerollable faces remain restricted.

Action Rerolls default to any time during the active hero's own turn. An optional Opening only setting closes that window after an ordinary action resolves/declines. Timing and refill are separate options.

Optional '1 reroll each turn' is OFF by default. When ON, each normal own turn or full immediate recovery turn refills that hero to at least 1 charge, up to the bank cap. Unused refills do not stack; earned extra charges remain. Shared rolls, Focus, rerolls, Shared Burden interrupts and redraws do not refill it. Switching ON applies from the next own turn and never gives an immediate charge. Keep these safeguards in a remake.

A rolled Blank normally does nothing unless an equipped Memory, Soulcaster or explicit setting provides a use. Optional Blank → Move 1 is OFF by default and spends a rolled Blank once per hero own turn. It does not install a movement face or give a free action. Toggling never refills the allowance. Rooted prevents voluntary movement. Soulcaster retains Gather/Manifest and gains a distinct Move 1 choice if the override is enabled.

## Status and timing invariants

Poison STACKS: Poison 1 plus Poison 1 becomes Poison 2. At that unit's own activation it deals its current value as unavoidable HP loss, then decreases by 1. It bypasses ordinary Block/reduction. Killing a unit or invalidating an action during a sequence must stop later ineligible operations.

Temporary Block normally expires at that unit's next turn start; printed effects such as Stonewake/Warden Soul can retain it. Stunned, Rooted, Weakness, Channels, reactions, temporary buffs, delayed penalties and limited per-turn effects use their printed reset points. They must not silently reset on redraw, reroll, a shared roll or someone else's action.

Zero HP is Downed unless Broken makes it death. Downed protection, healing into a Broken immediate recovery turn, the replaced normal initiative slot, later lethal damage and complete-party defeat must follow the detailed timing rules. A recovery turn is a full own turn; Shared Burden is only one borrowed action.

Borrow Shape chooses from CURRENT face-up hero die results, including eligible spent/held results, with its printed exclusions. It cannot inspect/select hidden unrolled installed sides. Installed-side effects, such as choosing a Blank for Engrave or spell creation, are separate operations. Engrave changes another eligible installed Blank when its trigger qualifies; it does not rewrite an already recorded roll. Physical side identity matters.

## Enemy intent and randomness

Every enemy ability has a target policy: self, area, ally support, marked cells, or ranked heroes. Policies include highest/lowest HP, most Block, furthest/closest, buffs, debuffs and prior-round damage as appropriate. Prefer a legal top-priority target, otherwise the closest legal fallback. Ties use a stable round-derived seed. Intent inspection and forecasts never consume combat RNG or reveal a hidden future result.

Numeric dice, optional balance profiles, Weakness, Pierce, Block, damage reduction, repeated hits, poison riders, healing and friendly-fire restrictions must use the actual formulas. Read the full face/boss entries and reference model for conditional ordering. Never replace the complete rules with a few generic attack/block skills.

## Normal progression and Trials remain distinct

Normal play includes party construction, a required pre-boss Ash Road event flow, boss selection, direct creature encounters and a persistent Camp. Direct creature battles do not substitute for the required pre-boss event. Normal crafting pays matching enemy Essence, validates ownership and physical copies, and binds Souls to individual heroes. Bosses yield 3 matching Essence; ordinary creatures normally yield 1 each when a complete encounter is won. Defeat/abandoning does not bank that fight's provisional kills.

Gold, Salves, Reroll Seals and Soul Fragments are distinct. Salve heals up to 2 HP in normal combat, once per hero own turn. A Seal restores 1 Action Reroll up to cap. Three Soul Fragments can unlock/bind the Ash Road Soul to a chosen hero under the current unlock condition. They are not generic crafting Essence. Exact event choices, checks and rewards are in the progression reference model.

Trials have exactly two starter classes, Skirmisher and Vanguard. Classes supply legal starting gear/dice and reward offers; effects still come from Body, Soul, Memory and Weapon. BOTH start with Memory empty. Soulcaster is a free alternate Trial starter Soul. Class choice is not an extra permanent modifier layer.

A Trial follows five route stops before its chosen existing boss, with combat, elite groups, ritual/spirit objectives, events, cache and Camp choices. HP carries; temporary encounter effects reset as specified. Run Essence buys run rewards; permanent Trial Forge ingredients/unlocks form a separate collection. Neither may spend or grant normal Camp resources. Safe route/reward checkpoints resume; leaving/reloading during combat fails that Trial. The first Memory can be earned after the first fight.

## Soulcaster

Soulcaster sets 6 HP and a minimum of 4 Blanks per die. Gather spends a rolled Blank for +1 Soul Charge, cap 3. Manifest spends a rolled Blank, the spell's charges and 1 HP to create a temporary encounter spell on that physical side; at most 4 spells may exist. A new spell cannot activate during its creation turn, including after a mid-turn reroll. It must roll on a later turn. Spells disappear after the encounter.

Hoarded Omen keeps the ORIGINAL die aside; it does not add a fourth ability alongside three new dice. Fatebreaker gains a capped Action Reroll and rerolls an eligible unresolved enemy die, once per enemy die per shared round. Mirror resolves reflection after the full Attack/rider/reaction sequence. Wraith, Harvester and Grave Stitch retain their range, charge, damage, movement and healing conditions. All six spell entries are included.

## Practice, storage and information

Test chamber is isolated practice: ability choices/forced Numeric values/reset/combination tests never consume real inventory or grant rewards. The current normal/earned chamber catalog has 73 entries; the complete game catalog additionally includes six projected weapon faces and six Soulcaster spell identities.

Choices can be inspected without payment. Crafting, equipping and reward purchases commit only after validation; rejected/invalid actions do not charge or partially mutate state. Keep owned but unequipped copies and per-hero bound Souls intact.

The player must be able to learn each ability, inspect enemy intent and targets, identify HP/Block/statuses and ready/spent/held/forced results, understand costs/rewards, and review a summary or complete causal battle log. This specifies information, not a HUD arrangement, color scheme, icon set or art style.

Presentation is separate from simulation. Animation, sound, accessibility and visual effects can be remade completely; they must not reroll RNG, apply damage/healing/rewards twice or let a presentation skip bypass a required rules choice. The old animation and pause setting defaults ON; disabling it changes presentation only.

This snapshot contains no personal saves or credentials. Existing browser/device save behavior is not a cloud account. A new implementation needs its own considered storage/migration policy.
